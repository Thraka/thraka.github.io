

 ██╗ ██████╗ ███████╗███████╗
███║██╔═████╗╚════██║╚════██║
╚██║██║██╔██║    ██╔╝    ██╔╝
 ██║████╔╝██║   ██╔╝    ██╔╝ 
 ██║╚██████╔╝   ██║██╗  ██║  
 ╚═╝ ╚═════╝    ╚═╝╚═╝  ╚═╝  

▄▄▄█████▓ ██░ ██ ▓█████   
▓  ██▒ ▓▒▓██░ ██▒▓█   ▀   
▒ ▓██░ ▒░▒██▀▀██░▒███     
░ ▓██▓ ░ ░▓█ ░██ ▒▓█  ▄   
  ▒██▒ ░ ░▓█▒░██▓░▒████▒  
  ▒ ░░    ▒ ░░▒░▒░░ ▒░ ░  
    ░     ▒ ░▒░ ░ ░ ░  ░  
  ░       ░  ░░ ░   ░     
          ░  ░  ░   ░  ░  
                          
▓█████  ███▄    █ ▓█████▄ 
▓█   ▀  ██ ▀█   █ ▒██▀ ██▌
▒███   ▓██  ▀█ ██▒░██   █▌
▒▓█  ▄ ▓██▒  ▐▌██▒░▓█▄   ▌
░▒████▒▒██░   ▓██░░▒████▓ 
░░ ▒░ ░░ ▒░   ▒ ▒  ▒▒▓  ▒ 
 ░ ░  ░░ ░░   ░ ▒░ ░ ▒  ▒ 
   ░      ░   ░ ░  ░ ░  ░ 
   ░  ░         ░    ░    
                   ░      

These playlists were taken from the Spotify links on this Reddit post: https://www.reddit.com/r/Seattle/comments/rlpp1x/top_107_from_9198/

Some songs are missing from the original playlists. The playlist index for each song may be slightly wrong due to those missing songs. Oh well. Enjoy!
