﻿static class GameSettings
{
    public const int GAME_WIDTH = 90;
    public const int GAME_HEIGHT = 30;    
}
